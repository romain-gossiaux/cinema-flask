create function update_seance(integer, timestamp without time zone) returns integer
    language plpgsql
as
$$
	declare 
		retour integer;
	begin
		UPDATE seance set date_heure = $2
		WHERE id = $1;
		
		GET DIAGNOSTICS retour = row_count;
		return retour;	
	end;
	
$$;

alter function update_seance(integer, timestamp) owner to anonyme;

