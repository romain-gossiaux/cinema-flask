create function delete_seance(integer) returns integer
    language plpgsql
as
$$
BEGIN
	DELETE FROM seance WHERE id = $1;
	RETURN 1;
END;
$$;

alter function delete_seance(integer) owner to anonyme;

