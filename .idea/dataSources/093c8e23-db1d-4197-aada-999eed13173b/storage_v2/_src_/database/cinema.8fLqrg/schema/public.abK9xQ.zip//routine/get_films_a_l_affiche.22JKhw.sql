create function get_films_a_l_affiche(integer) returns SETOF vue_seances_films
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
	SELECT *
	FROM vue_seances_films
	ORDER BY date_heure ASC
	LIMIT $1;
END
$$;

alter function get_films_a_l_affiche(integer) owner to anonyme;

