create function get_next_seance() returns vue_seances_films
    language plpgsql
as
$$
DECLARE
	retour vue_seances_films%ROWTYPE;
BEGIN
	SELECT * INTO retour
	FROM vue_seances_films
	WHERE date_heure = (
		SELECT MIN(date_heure)
		FROM seance
		WHERE date_heure > NOW()
	)
	LIMIT 1;

	RETURN retour;
END
$$;

alter function get_next_seance() owner to anonyme;

