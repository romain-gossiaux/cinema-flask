create function get_searched_films(text) returns SETOF film
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
	SELECT *
	FROM film
	WHERE LOWER(titre) LIKE LOWER($1 || '%');
END
$$;

alter function get_searched_films(text) owner to anonyme;

