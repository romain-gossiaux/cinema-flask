create function delete_reservation(integer) returns integer
    language plpgsql
as
$$
BEGIN
	DELETE FROM reservation WHERE id = $1;
	RETURN 1;
END;
$$;

alter function delete_reservation(integer) owner to anonyme;

