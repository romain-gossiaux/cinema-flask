create view vue_seances_films(id_seance, date_heure, id_film, titre, duree, affiche) as
SELECT s.id AS id_seance,
       s.date_heure,
       f.id AS id_film,
       f.titre,
       f.duree,
       f.affiche
FROM seance s
         JOIN film f ON s.id_film = f.id;

alter table vue_seances_films
    owner to anonyme;

